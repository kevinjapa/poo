/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controlador;

import java.util.ArrayList;
import java.util.List;
import modelo.Cliente;
import modelo.Factura;
import modelo.*;

/**
 *
 * @author japak
 */
public class ControladorFactura {
    private List<Factura> listaFactura;
    private Factura seleccionado;
    public ControladorFactura(){
        listaFactura=new ArrayList();
        seleccionado=null;
    }
    public long generarId(){
        if(listaFactura.size() > 0)
            return listaFactura.get(listaFactura.size() -1).getId() + 1;
        return 1;
    }
    public boolean crear(Cliente cliente, Servicio servico, double valorTotal, Contrato contrato){
        Factura empresa = new Factura((int) generarId(),cliente,servico, valorTotal, contrato );
        return listaFactura.add(empresa);
    }
    
    public Factura buscar(Double id){
        for (Factura empresa : listaFactura) {
            if(empresa.getId()==id){
                return empresa;
            }
        }
        return null;
    }
    
    public boolean eliminar(Double id){
        Factura factura = this.buscar(id);
        if(factura != null) {
            return listaFactura.remove(factura);
        }
        return false;
    }

    public List<Factura> getListaFactura() {
        return listaFactura;
    }

    public void setListaFactura(List<Factura> listaFactura) {
        this.listaFactura = listaFactura;
    }

    public Factura getSeleccionado() {
        return seleccionado;
    }

    public void setSeleccionado(Factura seleccionado) {
        this.seleccionado = seleccionado;
    }
    
}