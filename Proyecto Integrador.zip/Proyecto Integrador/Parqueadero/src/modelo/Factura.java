/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

/**
 *
 * @author japak
 */
public class Factura {
    
     private int id;
    private Cliente cliente;
    private Servicio servico;
    private double valorTotal;
    private Contrato contrato;

    public Factura(int id, Cliente cliente, Servicio servico, double valorTotal, Contrato contrato) {
        this.id = id;
        this.cliente = cliente;
        this.servico = servico;
        this.valorTotal = valorTotal;
        this.contrato = contrato;
    }

    public Factura(int id, Servicio servico, double valorTotal, Contrato contrato) {
        this.id = id;
        this.servico = servico;
        this.valorTotal = valorTotal;
        this.contrato = contrato;
    }
     
   /* public Factura() {
    }*/

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Cliente getCliente() {
        return cliente;
    }

    public void setCliente(Cliente cliente) {
        this.cliente = cliente;
    }

    public Servicio getServico() {
        return servico;
    }

    public void setServico(Servicio servico) {
        this.servico = servico;
    }

    public double getValorTotal() {
        return valorTotal;
    }

    public void setValorTotal(double valorTotal) {
        this.valorTotal = valorTotal;
    }

    public Contrato getContrato() {
        return contrato;
    }

    public void setContrato(Contrato contrato) {
        this.contrato = contrato;
    }

    @Override
    public String toString() {
        return "Factura{" + "id=" + id + ", cliente=" + cliente + ", servico=" + servico + ", valorTotal=" + valorTotal + ", contrato=" + contrato + '}';
    }
    
}