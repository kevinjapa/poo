/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package interfaz;

import controlador.ClienteControlador;
import controlador.ControladorContrato;
import javax.swing.JOptionPane;
import modelo.Cliente;

/**
 *
 * @author japak
 */
public class ContratoVista extends javax.swing.JInternalFrame {

    ControladorContrato controladorContrato;
    ClienteControlador controladorCliente;
    private String opcion;
    public ContratoVista(ClienteControlador clienteControlador) 
    {
        
        initComponents();
        controladorContrato=new ControladorContrato();
        this.controladorCliente=clienteControlador;
        
    }
    
    public void validarRadioButon()
    {
        if(rbtn1.isSelected()==false && rbtn2.isSelected()==false && rbtn3.isSelected()==false && rbtn4.isSelected()==false)
        {
            JOptionPane.showMessageDialog(null,"No selecciono ninguna opción");
            
        }
    }
    public void obtenerOpcion()
    {
        if(rbtn1.isSelected()==true )
            opcion=rbtn1.getText();
        else if(rbtn2.isSelected()==true)
            opcion=rbtn2.getText();
        else if(rbtn3.isSelected()==true)
            opcion=rbtn3.getText();
        else if(rbtn4.isSelected()==true)
            opcion=rbtn4.getText();
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        lblCedula = new javax.swing.JLabel();
        txtCedula = new javax.swing.JTextField();
        lblDuracionContrato = new javax.swing.JLabel();
        rbtn1 = new javax.swing.JRadioButton();
        rbtn2 = new javax.swing.JRadioButton();
        rbtn3 = new javax.swing.JRadioButton();
        rbtn4 = new javax.swing.JRadioButton();
        btnCrearContrato = new javax.swing.JButton();

        setClosable(true);
        setIconifiable(true);
        setMaximizable(true);
        setTitle("Contrato");

        lblCedula.setText("Ingrese la cedula ");

        txtCedula.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtCedulaActionPerformed(evt);
            }
        });

        lblDuracionContrato.setText("Duracion de Contrato:");

        rbtn1.setText("3 dias ");

        rbtn2.setText("5 dias ");

        rbtn3.setText("1 Semana");

        rbtn4.setText("1 Mes");

        btnCrearContrato.setText("Crear Contrato");
        btnCrearContrato.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCrearContratoActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(0, 75, Short.MAX_VALUE)
                .addComponent(rbtn1)
                .addGap(33, 33, 33)
                .addComponent(rbtn2)
                .addGap(43, 43, 43)
                .addComponent(rbtn3)
                .addGap(40, 40, 40)
                .addComponent(rbtn4)
                .addGap(67, 67, 67))
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(59, 59, 59)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(lblDuracionContrato)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(lblCedula)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(txtCedula, javax.swing.GroupLayout.PREFERRED_SIZE, 181, javax.swing.GroupLayout.PREFERRED_SIZE))))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(197, 197, 197)
                        .addComponent(btnCrearContrato)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(36, 36, 36)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblCedula)
                    .addComponent(txtCedula, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(lblDuracionContrato)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(rbtn1)
                    .addComponent(rbtn2)
                    .addComponent(rbtn3)
                    .addComponent(rbtn4))
                .addGap(50, 50, 50)
                .addComponent(btnCrearContrato)
                .addContainerGap(164, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void txtCedulaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtCedulaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtCedulaActionPerformed

    private void btnCrearContratoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCrearContratoActionPerformed
        validarRadioButon();
        obtenerOpcion();
        System.out.println("vbnjm"+controladorCliente.getDatos());
        controladorCliente.buscar(txtCedula.getText());
        controladorContrato.crear(opcion,controladorCliente.buscar(txtCedula.getText()));
        
    }//GEN-LAST:event_btnCrearContratoActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnCrearContrato;
    private javax.swing.JLabel lblCedula;
    private javax.swing.JLabel lblDuracionContrato;
    private javax.swing.JRadioButton rbtn1;
    private javax.swing.JRadioButton rbtn2;
    private javax.swing.JRadioButton rbtn3;
    private javax.swing.JRadioButton rbtn4;
    private javax.swing.JTextField txtCedula;
    // End of variables declaration//GEN-END:variables
}
