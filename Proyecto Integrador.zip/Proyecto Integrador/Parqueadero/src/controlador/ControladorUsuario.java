/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controlador;

import java.util.ArrayList;
import java.util.List;
import modelo.Usuario;

/**
 *
 * @author japak
 */
public class ControladorUsuario 
{
    private List<Usuario> listaUsuario =new ArrayList();;
    private Usuario seleccionado;
    public ControladorUsuario()
    {
        seleccionado=null;
        agregarUser();
    }
    
    public long generarId()
    {
        return (listaUsuario.size()>0)? listaUsuario.get(listaUsuario.size()-1).getId()+1:1;
    }
    public boolean crear(String correo, String contraseña, String puesto)
    {
        return listaUsuario.add(new Usuario(generarId(),correo,contraseña,puesto));
    }
    public Usuario buscarUsuario(String correo,String contraseña)
    {
        for(Usuario usuario: listaUsuario)
        {
            if(usuario.getCorreo().equals(correo)&& usuario.getContraseña().equals(contraseña))
            {
                seleccionado= usuario;
                return usuario;
            }
           
        }
         return null;
    }
    public Usuario buscarUsuarioPuesto(String correo)
    {
        for(Usuario usuario: listaUsuario)
        {
            if(usuario.getCorreo().equals(correo))
            {
                seleccionado= usuario;
                return usuario;
            }
           
        }
         return null;
    }
public boolean puesto(String correo)
    {
        Usuario usuario=buscarUsuarioPuesto(correo);
        if(usuario.getPuesto().equals("administrador"))
        {
            return true;
        }
        else
        {
            return false;
        }
       
    }
    public boolean verificacion(String correo, String contraseña)
    {
        Usuario usuario=buscarUsuario(correo,contraseña);
        if(usuario!=null)
        {
            System.out.println("correcto"); 
            return true; 
        }
        else
        {
            System.out.println("incorrecto");
            return false;
        }
    }
    public boolean actualizar(String correo, String contraseña,String puesto)
    {
        Usuario usuario=buscarUsuario(correo,contraseña);
        if(usuario!=null)
        {
            int posicion=listaUsuario.indexOf(correo);
            usuario.setContraseña(contraseña);
            usuario.setPuesto(puesto);
            listaUsuario.set(posicion, usuario);
            return true;
        }
        return false;
    }
    public boolean eliminar(String correo,String contraseña)
    {
        Usuario usuario=buscarUsuario(correo,contraseña);
        return listaUsuario.remove(usuario);
    }
    public void listar()
    {
        System.out.println(listaUsuario);
    }
    public void agregarUser()
    {
        crear("kevin", "kevin", "administrador");
        crear("kevinjapa", "kevin", "usuario");
    }

    public List<Usuario> getListaUsuario() {
        return listaUsuario;
    }

    public void setListaUsuario(List<Usuario> listaUsuario) {
        this.listaUsuario = listaUsuario;
    }

    public Usuario getSeleccionado() {
        return seleccionado;
    }

    public void setSeleccionado(Usuario seleccionado) {
        this.seleccionado = seleccionado;
    }
    
}
