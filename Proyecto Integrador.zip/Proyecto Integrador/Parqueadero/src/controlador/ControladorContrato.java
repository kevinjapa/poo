/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controlador;

import modelo.Contrato;
import java.util.ArrayList;
import java.util.List;
import modelo.Cliente;

/**
 *
 * @author japak
 */
public class ControladorContrato {
    private List<Contrato> datos;
    private Contrato seleccionado;
    
    public ControladorContrato() {
        datos = new ArrayList<Contrato>();
        seleccionado = null;
    }
    public long generarId(){
        if(datos.size() > 0)
            return datos.get(datos.size() -1).getId() + 1;
        return 1;
    }
    // Metodos CRUD 
    public boolean crear(String duracionArriendo,Cliente cliente) {
        Contrato contrato = new Contrato(duracionArriendo,generarId(),cliente); 
        datos.add(contrato);
        System.out.println(datos);
        return true; 
    }
     public Contrato buscar(String duracionArriendo){
        for (Contrato contrato : datos) { 
            if(contrato.getDuracionArriendo().equals(duracionArriendo) == true){ 
                return contrato; 
            }
        }
        return null; 
    }
    
    public boolean actualizar(String duracionArriendo, int valorTotal) {
        Contrato contrato = this.buscar(duracionArriendo); 
        if(contrato!= null) { 
            int posicion = datos.indexOf(contrato);
            contrato.setDuracionArriendo(duracionArriendo); 
            contrato.setValorTotal(valorTotal); 
            datos.set(posicion, contrato); 
            return true;
        }
        return false;
    }
    public boolean eliminar(String duracionArriendo){
        Contrato contrato = this.buscar(duracionArriendo);
        if(contrato != null) {
            return datos.remove(contrato);
        }
        return false;
    }
  
    public List<Contrato> getDatos() {
        return datos;
    }

    public void setDatos(List<Contrato> datos) {
        this.datos = datos;
    }

    public Contrato getSeleccionado() {
        return seleccionado;
    }

    public void setSeleccionado(Contrato seleccionado) {
        this.seleccionado = seleccionado;
    }
    
}
