/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

/**
 *
 * @author japak
 */
public class Usuario 
{
    private long Id;
    private String correo;
    private String contraseña;
    private String puesto;
    
    public Usuario()
    {
        
    }
    public Usuario(long Id, String correo, String contraseña) {
        this.Id = Id;
        this.correo = correo;
        this.contraseña = contraseña;
    }

    public Usuario(long Id, String correo, String contraseña, String puesto) {
        this.Id = Id;
        this.correo = correo;
        this.contraseña = contraseña;
        this.puesto = puesto;
    }
    
    
    public long getId() {
        return Id;
    }

    public void setId(long Id) {
        this.Id = Id;
    }

    public String getCorreo() {
        return correo;
    }

    public void setCorreo(String correo) {
        this.correo = correo;
    }

    public String getContraseña() {
        return contraseña;
    }

    public void setContraseña(String contraseña) {
        this.contraseña = contraseña;
    }

    public String getPuesto() {
        return puesto;
    }

    public void setPuesto(String puesto) {
        this.puesto = puesto;
    }

    @Override
    public String toString() {
        return "Usuario{" + "correo=" + correo + ", contrase\u00f1a=" + contraseña + ", puesto=" + puesto + '}';
    }
    
    
    
}
