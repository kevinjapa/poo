/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package interfaz;

import archivo.ArchivoObjeto;
import archivo.ArchivoTexto;
import archivo.ArchivosBinarios;
import archivo.ArchivosBinariosAleatorio;
import controlador.ClienteControlador;
import controlador.ControladorUsuario;
import controlador.EmpresaControlador;
import controlador.ServicioControlador;
import controlador.VehiculoControlador;

/**
 *
 * @author diego
 */
public class Principal extends javax.swing.JFrame {
    
    private EmpresaControlador empresaControlador;
    private ClienteControlador clienteControlador;
    private VehiculoControlador vehiculoControlador;
    private ServicioControlador servicioControlador;
    private ArchivoObjeto archivoObjeto;
    private ArchivosBinarios archivosBinarios;
    private ArchivosBinariosAleatorio archivosBinariosAleatorio;
    private ControladorUsuario controladorUsuario;
    private InciarSecion iniciarSecion;
    public Principal() {
        initComponents();
        
        empresaControlador = new EmpresaControlador();
        clienteControlador = new ClienteControlador();
        vehiculoControlador = new VehiculoControlador();
        servicioControlador = new ServicioControlador();
        archivoObjeto = new ArchivoObjeto("/home/diego/UPS/56/ProgramacionAplicada/Parqueadero/src/archivo/ClienteArchivo.obj");// Ruta Absolojuta
        archivosBinarios = new ArchivosBinarios();
        archivosBinariosAleatorio = new ArchivosBinariosAleatorio("ServicioArchivo.dat");//Ruta relativa
        
    }
    public Principal(ControladorUsuario controladorUsuario) {
        initComponents();
        this.controladorUsuario= controladorUsuario;
        empresaControlador = new EmpresaControlador();
        clienteControlador = new ClienteControlador();
        vehiculoControlador = new VehiculoControlador();
        servicioControlador = new ServicioControlador();
        archivoObjeto = new ArchivoObjeto("/home/diego/UPS/56/ProgramacionAplicada/Parqueadero/src/archivo/ClienteArchivo.obj");// Ruta Absolojuta
        archivosBinarios = new ArchivosBinarios();
        archivosBinariosAleatorio = new ArchivosBinariosAleatorio("ServicioArchivo.dat");//Ruta relativa
        
    }
    
    public void nivelOperacion()
    {
        String palabra=controladorUsuario.getSeleccionado().getCorreo();
        
        if(controladorUsuario.puesto(palabra)!=true)
        {
            mnuEmpListar.setVisible(false);
            mniGestion.setVisible(false);
            mnuGestion.setVisible(false);
        }
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jMenu1 = new javax.swing.JMenu();
        dtpPrincipal = new javax.swing.JDesktopPane();
        btnInicio = new javax.swing.JButton();
        btnCerrarSecion = new javax.swing.JButton();
        jMenuBar1 = new javax.swing.JMenuBar();
        jMenu2 = new javax.swing.JMenu();
        jmiCerrarSesion = new javax.swing.JMenuItem();
        mnuEmpresa = new javax.swing.JMenu();
        mnuEmpListar = new javax.swing.JMenuItem();
        mnuCliente = new javax.swing.JMenu();
        mniGestion = new javax.swing.JMenuItem();
        mnuVehiculo = new javax.swing.JMenu();
        mnuGestion = new javax.swing.JMenuItem();
        mnuServicio = new javax.swing.JMenu();
        mniParqueadero = new javax.swing.JMenuItem();
        btniEstadoParqueadero = new javax.swing.JMenuItem();
        btniContrato = new javax.swing.JMenuItem();

        jMenu1.setText("jMenu1");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Parqueadero UPS");

        dtpPrincipal.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));

        btnInicio.setFont(new java.awt.Font("Arial", 0, 11)); // NOI18N
        btnInicio.setForeground(new java.awt.Color(102, 102, 102));
        btnInicio.setText("Iniciar");
        btnInicio.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnInicioActionPerformed(evt);
            }
        });

        btnCerrarSecion.setFont(new java.awt.Font("Arial", 0, 11)); // NOI18N
        btnCerrarSecion.setForeground(new java.awt.Color(102, 102, 102));
        btnCerrarSecion.setText("Cerrar Sesion");
        btnCerrarSecion.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCerrarSecionActionPerformed(evt);
            }
        });

        dtpPrincipal.setLayer(btnInicio, javax.swing.JLayeredPane.DEFAULT_LAYER);
        dtpPrincipal.setLayer(btnCerrarSecion, javax.swing.JLayeredPane.DEFAULT_LAYER);

        javax.swing.GroupLayout dtpPrincipalLayout = new javax.swing.GroupLayout(dtpPrincipal);
        dtpPrincipal.setLayout(dtpPrincipalLayout);
        dtpPrincipalLayout.setHorizontalGroup(
            dtpPrincipalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(dtpPrincipalLayout.createSequentialGroup()
                .addGap(258, 258, 258)
                .addComponent(btnInicio, javax.swing.GroupLayout.PREFERRED_SIZE, 113, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(115, 115, 115)
                .addComponent(btnCerrarSecion, javax.swing.GroupLayout.PREFERRED_SIZE, 116, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(547, Short.MAX_VALUE))
        );
        dtpPrincipalLayout.setVerticalGroup(
            dtpPrincipalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(dtpPrincipalLayout.createSequentialGroup()
                .addGap(218, 218, 218)
                .addGroup(dtpPrincipalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnCerrarSecion, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnInicio, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(313, Short.MAX_VALUE))
        );

        jMenu2.setText("Menu");

        jmiCerrarSesion.setText("Cerrar Sesion");
        jmiCerrarSesion.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jmiCerrarSesionActionPerformed(evt);
            }
        });
        jMenu2.add(jmiCerrarSesion);

        jMenuBar1.add(jMenu2);

        mnuEmpresa.setText("Empresa");

        mnuEmpListar.setText("Operaciones");
        mnuEmpListar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mnuEmpListarActionPerformed(evt);
            }
        });
        mnuEmpresa.add(mnuEmpListar);

        jMenuBar1.add(mnuEmpresa);

        mnuCliente.setText("Clientes");

        mniGestion.setText("Gestión");
        mniGestion.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mniGestionActionPerformed(evt);
            }
        });
        mnuCliente.add(mniGestion);

        jMenuBar1.add(mnuCliente);

        mnuVehiculo.setText("Vehiculo");

        mnuGestion.setText("Gestion");
        mnuGestion.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mnuGestionActionPerformed(evt);
            }
        });
        mnuVehiculo.add(mnuGestion);

        jMenuBar1.add(mnuVehiculo);

        mnuServicio.setText("Servicio");

        mniParqueadero.setText("Parqueadero");
        mniParqueadero.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mniParqueaderoActionPerformed(evt);
            }
        });
        mnuServicio.add(mniParqueadero);

        btniEstadoParqueadero.setText("Estado de Parqueadero");
        btniEstadoParqueadero.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btniEstadoParqueaderoActionPerformed(evt);
            }
        });
        mnuServicio.add(btniEstadoParqueadero);

        btniContrato.setText("Contrato");
        btniContrato.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btniContratoActionPerformed(evt);
            }
        });
        mnuServicio.add(btniContrato);

        jMenuBar1.add(mnuServicio);

        setJMenuBar(jMenuBar1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addComponent(dtpPrincipal)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(dtpPrincipal)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void mnuEmpListarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mnuEmpListarActionPerformed
       
        EmpresaVista empresa = new EmpresaVista(empresaControlador);
        dtpPrincipal.add(empresa);
        empresa.show();

    }//GEN-LAST:event_mnuEmpListarActionPerformed

    private void mniGestionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mniGestionActionPerformed
        
        ClienteVista clienteVista = new ClienteVista(clienteControlador, empresaControlador, archivoObjeto);
        dtpPrincipal.add(clienteVista);
        clienteVista.show();
    }//GEN-LAST:event_mniGestionActionPerformed

    private void mnuGestionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mnuGestionActionPerformed
        
        VehiculoVista vehiculoVista = new VehiculoVista(vehiculoControlador, clienteControlador, archivosBinarios);
        dtpPrincipal.add(vehiculoVista);
        vehiculoVista.show();
    }//GEN-LAST:event_mnuGestionActionPerformed

    private void mniParqueaderoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mniParqueaderoActionPerformed
        ServicioVista servicioVista = new ServicioVista(vehiculoControlador, servicioControlador, archivosBinariosAleatorio);
        dtpPrincipal.add(servicioVista);
        servicioVista.show();
    }//GEN-LAST:event_mniParqueaderoActionPerformed

    private void btnInicioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnInicioActionPerformed
       nivelOperacion();
       btnInicio.setVisible(false);
       btnCerrarSecion.setVisible(false);
    }//GEN-LAST:event_btnInicioActionPerformed

    private void btnCerrarSecionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCerrarSecionActionPerformed
        iniciarSecion =new InciarSecion(controladorUsuario);
        iniciarSecion.setVisible(true);
        dispose();
    }//GEN-LAST:event_btnCerrarSecionActionPerformed

    private void jmiCerrarSesionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jmiCerrarSesionActionPerformed
        iniciarSecion =new InciarSecion(controladorUsuario);
        iniciarSecion.setVisible(true);
        dispose();
    }//GEN-LAST:event_jmiCerrarSesionActionPerformed

    private void btniContratoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btniContratoActionPerformed
        ContratoVista contratoVista=new ContratoVista(clienteControlador);
        dtpPrincipal.add(contratoVista);
        contratoVista.show();
    }//GEN-LAST:event_btniContratoActionPerformed

    private void btniEstadoParqueaderoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btniEstadoParqueaderoActionPerformed
        TablaPuestoParqueadero parqueadero=new TablaPuestoParqueadero();
        dtpPrincipal.add(parqueadero);
        parqueadero.show();
    }//GEN-LAST:event_btniEstadoParqueaderoActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Principal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Principal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Principal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Principal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Principal().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnCerrarSecion;
    private javax.swing.JButton btnInicio;
    private javax.swing.JMenuItem btniContrato;
    private javax.swing.JMenuItem btniEstadoParqueadero;
    private javax.swing.JDesktopPane dtpPrincipal;
    private javax.swing.JMenu jMenu1;
    private javax.swing.JMenu jMenu2;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JMenuItem jmiCerrarSesion;
    private javax.swing.JMenuItem mniGestion;
    private javax.swing.JMenuItem mniParqueadero;
    private javax.swing.JMenu mnuCliente;
    private javax.swing.JMenuItem mnuEmpListar;
    private javax.swing.JMenu mnuEmpresa;
    private javax.swing.JMenuItem mnuGestion;
    private javax.swing.JMenu mnuServicio;
    private javax.swing.JMenu mnuVehiculo;
    // End of variables declaration//GEN-END:variables
}
