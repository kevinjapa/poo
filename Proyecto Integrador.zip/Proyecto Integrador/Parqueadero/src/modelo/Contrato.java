package modelo;

import java.util.List;

/**
 *
 * @author Erika
 */
public class Contrato {
    private long id;
    private String duracionArriendo;
    private int valorTotal;
    
    private Cliente cliente;
     public Contrato() {
        this.id = -1;
    }

     //
    public Contrato(String duracionArriendo, long id, Cliente cliente) {
        this.duracionArriendo = duracionArriendo;
        this.valorTotal = valorTotal;
        this.id = id;
    }

    public Contrato(String duracionArriendo, int valorTotal, long id, Cliente cliente) {
        this.duracionArriendo = duracionArriendo;
        this.valorTotal = valorTotal;
        this.id = id;
        this.cliente = cliente;
    }

    public String getDuracionArriendo() {
        return duracionArriendo;
    }

    public void setDuracionArriendo(String duracionArriendo) {
        this.duracionArriendo = duracionArriendo;
    }

    public int getValorTotal() {
        return valorTotal;
    }

    public void setValorTotal(int valorTotal) {
        this.valorTotal = valorTotal;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public Cliente getCliente() {
        return cliente;
    }

    public void setCliente(Cliente cliente) {
        this.cliente = cliente;
    }

    @Override
    public String toString() {
        return "Contrato{" + "duracionArriendo=" + duracionArriendo + ", valorTotal=" + valorTotal + ", id=" + id + ", cliente=" + cliente + '}';
    }
   
}